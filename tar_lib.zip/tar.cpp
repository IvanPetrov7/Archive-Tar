#include <iostream>
#include <stdio.h>
#include <vector>
#include <string>
#include <cstring>
#include <sstream>
#include "microtar.h"
#include "tar.hpp"
using namespace std;

Tar::Tar(string name, int m){
   mode=m;
   mtar_header_t h;
   Folder *f;
   string s, s1; 
   
   if (mode==1){
      mtar_open(&archive, name.c_str(), "w");
   }
   else{
      add(new Folder(""));
      mtar_open(&archive, name.c_str(), "r");
      while ( (mtar_read_header(&archive, &h)) != MTAR_ENULLRECORD ){//����� �� �����
         s=h.name;
     	 //printf("%s (%d bytes)\n", h.name, h.size);
         //printf("%c", h.type); 
         if (h.type=='5'){
            s.pop_back();
            add(new Folder(s));
         } 
         else{
            size_t pos=s.rfind("/");
            if (pos==string::npos){
               f=fold[0];
            }
            else{ 
               string fname=s.substr(0,pos);
               f=nullptr;
               for(auto fi:fold)
                  if(fi->get_name()==fname){
                     f=fi;
                     break;
                  }
               if(f==nullptr)
                  add(f=new Folder(fname));
               s.erase(0, pos);
            }
            f->add(new File(s, h.size, f));//��������� �� �����
         }
         mtar_next(&archive);
      } 
   }
}

void Tar::add(Folder *f){
   f->arch=this;
   if (mode==1) {
      f->name+='/';
      mtar_write_dir_header(&archive, f->name.c_str());
   }
   fold.push_back(f); 
}

void Tar::close(){
   if (mode==1) mtar_finalize(&archive);
   mtar_close(&archive);
}

Tar::~Tar(){
   for (int i=0; i<fold.size(); i++) delete fold[i];
   fold.clear();
   if (mode==1) mtar_finalize(&archive);
   mtar_close(&archive);
}

Folder::~Folder(){
   for (int i=0; i<file.size(); i++) delete file[i];
   file.clear();
}

Input::Input(File &f):f(f){
   mtar_header_t h; 
   if (f.fold->name=="") mtar_find(&f.fold->arch->archive, f.get_name().c_str(), &h);
   else mtar_find(&f.fold->arch->archive, f.get_fullname().c_str(), &h);
   char *s = new char[h.size+1];
   mtar_read_data(&f.fold->arch->archive, s, h.size);
   s[h.size]=0;
   str(s);
   delete [] s;
}

Output::~Output(){
   string s;
   s = str();
   mtar_write_file_header(&f.fold->arch->archive, this->f.get_fullname().c_str(), strlen(s.c_str()));
   mtar_write_data(&f.fold->arch->archive, s.c_str(), strlen(s.c_str()));
}